import styled from '@emotion/styled';

const AnimeCollectionWrapper = styled.div`
	display:block;
	margin: 50px 0;
`;

export default AnimeCollectionWrapper;